# Change Log
 
 - 2.0.0
     - Added Debug Bundle Collection
     - Added some additional tables data collection
 - 1.0.3
   - Added compliance for multicast deployment CSCvv89025
   - Removed release name from readme file as per feedback
   - Added all sda app data collection option


 - 1.0.2 (03rd Nov 2020)
   - Merged Audit and Telemetry Report
   - Compliance Report and Log content separated
   - Report format changed for Compliance , Audit and Telemetry
   - Compliance added for defect : CSCvw03683
   
      
 - 1.0.1 (15th October 2020)
    - Included Live Log Analyze option in Log analyzer
    - Fixed inventory log analyzer script execution issue
    - Separated the Compliance checker script from Database data collector
    - Enhanced database data collection and console logs
    - Added SDA Audit Report
    - Added SDA Telemetry Report
    - Added SDA Compliance Report
    - Included pdf report generation
    
      
- 1.0.0 - First release