import os


version ='2.0.0'  # TODO FIXME

class color:
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    DARKCYAN = '\033[36m'
    BLUE = '\033[94m'
    GREEN = '\033[32m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'

option,option2,log_option,file_path='','','',''
def introduction():

    print(color.DARKCYAN+"*" * 77)
    print("*" * 77)
    print("*****"+" "* 67+"*****");
    print("*****"+" " * 10+"Welcome to the Cisco DNA Center Analyzer Tool"+" "* 12+"*****")
    print("*****"+" " * 25+"Version {}".format(version)+" "* 29+"*****")
    print("*****"+" "* 67+"*****");
    print("*" * 77)
    print("*" * 77+color.END)
    
    main_menu()

def main_menu():
    global option
    print("\n")
    print(color.BOLD + color.DARKCYAN + "\t\t\t\t\t\t Cisco DNAC Data Analyzer" + color.END)
    print(color.BOLD + color.BLUE + "\t\t "  + "Options" + color.END)
    print(color.PURPLE + "\t\t\t 1 -> Debug Bundle Collector " + color.END)
    print(color.PURPLE + "\t\t\t 2 -> Log Analyzer " + color.END)
    print(color.PURPLE + "\t\t\t 3 -> Database Data Collection " + color.END)
    print(color.PURPLE + "\t\t\t 4 -> Database Compliance checker " + color.END)
    print(color.PURPLE + "\t\t\t 5 -> SDA Audit and Telemetry " + color.END)
    #print(color.PURPLE + "\t\t\t 6 -> Search Known Cisco External Defect / Issues " + color.END)
    print(color.BLUE + "\t\t\t 7 -> Exit " + color.END)
    print(color.DARKCYAN+"\n\n\t For Feedback/Support Reachout : log-analyzer-feedback@cisco.com"+ color.END+"\n")
    print("*" * 75)
    option = int(input(color.GREEN + "\n\t Enter the Option : " + color.END))
    print(option)
    if option==1:
        debug_bundle_menu_fn()
    elif option==2:
        log_menu()
    elif option==3:
        database_data_collection_fn()
    else:
        cmd=ses.exec('python DNA_Analyzer.py '+str(option)) #1argument
        print(cmd)
    '''elif option==6:
        try:
            searchString = raw_input(color.GREEN + "\n\t Enter Search String (exit): " + color.END)
        except:
            searchString = input(color.GREEN + "\n\t Enter Search String : " + color.END)
        cmd=ses.exec('python DNA_Analyzer.py '+str(option)+" "+str(searchString)) 
        print(cmd)'''
    

def database_data_collection_fn():
    print("*" * 75)
    print(color.BOLD + color.DARKCYAN + "\t\t\t\t\t\t Database Data Collection " + color.END)
    print(color.BOLD + color.BLUE + "\t\t " + "Options" + color.END)
    print(color.PURPLE + "\t\t\t 1 -> All SDA Application " + color.END)
    print(color.PURPLE + "\t\t\t 2 -> LAN Automation " + color.END)
    print(color.PURPLE + "\t\t\t 3 -> Device Provision " + color.END)
    print(color.PURPLE + "\t\t\t 4 -> Host Onboarding " + color.END)
    print(color.PURPLE + "\t\t\t 5 -> Device based Data Collection " + color.END)
    print(color.PURPLE + "\t\t\t 6 -> IPAM  " + color.END)
    print(color.PURPLE + "\t\t\t 7 -> ISE  " + color.END)
    print(color.PURPLE + "\t\t\t 8 -> Migration " + color.END)
    print(color.PURPLE + "\t\t\t 9 -> SSID Provisioning " + color.END)
    print(color.PURPLE + "\t\t\t 10 -> AP Provisioning " + color.END)
    print(color.BLUE + "\t\t\t 11 -> Previous Menu" + color.END)
    print(color.BLUE + "\t\t\t 12 -> Exit" + color.END)
    print("*" * 75)
    option2 = int(input(color.GREEN + "\n\t Enter the Option : " + color.END))

    if option2==1:
        try:
            deviceip = raw_input(color.GREEN + "\n\t Enter the Device IP Address : " + color.END)
        except:
            deviceip = input(color.GREEN + "\n\t Enter the Device IP Address : " + color.END)
        try:
            deviceip2 = raw_input(color.GREEN + "\n\t Enter the WLC IP Address : " + color.END)
        except:
            deviceip2 = input(color.GREEN + "\n\t Enter the WLC IP Address : " + color.END)
        try:
            ssid_name = raw_input(color.GREEN + "\n\t Enter the SSID NAME : " + color.END)
        except:
            ssid_name = input(color.GREEN + "\n\t Enter the SSID NAME : " + color.END)
        cmd=ses.exec('python DNA_Analyzer.py '+str(option)+" "+str(option2)+" "+str(deviceip)+" "+str(deviceip2)+" "+str(ssid_name))


    elif option2==5:
        try:
            deviceip = raw_input(color.GREEN + "\n\t Enter the Device IP Address : " + color.END)
        except:
            deviceip = input(color.GREEN + "\n\t Enter the Device IP Address : " + color.END)
        cmd=ses.exec('python DNA_Analyzer.py '+str(option)+" "+str(option2)+" "+str(deviceip))
        print(cmd)
    
    elif option2==8:
        try:
            deviceip2 = raw_input(color.GREEN + "\n\t Enter the WLC IP Address : " + color.END)
        except:
            deviceip2 = input(color.GREEN + "\n\t Enter the WLC IP Address : " + color.END)
        cmd=ses.exec('python DNA_Analyzer.py '+str(option)+" "+str(option2)+" "+str(deviceip2))
        print(cmd)
    elif option2==10:
        try:
            ssid_name = raw_input(color.GREEN + "\n\t Enter the SSID NAME : " + color.END)
        except:
            ssid_name = input(color.GREEN + "\n\t Enter the SSID NAME : " + color.END)
        cmd=ses.exec('python DNA_Analyzer.py '+str(option)+" "+str(option2)+" "+str(ssid_name))
        print(cmd)
    else:    
        cmd=ses.exec('python DNA_Analyzer.py '+str(option)+" "+str(option2))
        print(cmd)



def debug_bundle_menu_fn():
    print(color.BOLD + color.DARKCYAN + "\t\t\t\t\t\t Collect Debug Bundle" + color.END)
    print(color.BOLD + color.BLUE + "\t\t "  + "Options" + color.END)
    print(color.PURPLE + "\t\t\t 1 -> LAN Automation " + color.END)
    print(color.PURPLE + "\t\t\t 2 -> Provision " + color.END)
    print(color.BLUE + "\t\t\t 3 -> Exit" + color.END)
    print("*" * 75)

    option2 = int(input(color.GREEN + "\n\t Enter the Option : " + color.END))
    cmd=ses.exec('python DNA_Analyzer.py '+str(option)+" "+str(option2)) #2 arguments
    print(cmd)


def log_menu():
    print(color.BOLD + color.DARKCYAN + "\t\t\t\t\t\t DNA Log Analyzer" + color.END)
    print(color.BOLD + color.BLUE + "\t\t "  + "Options" + color.END)
    print(color.PURPLE + "\t\t\t 1 -> Inventory Service " + color.END)
    print(color.PURPLE + "\t\t\t 2 -> Spf Service Manager " + color.END)
    print(color.PURPLE + "\t\t\t 3 -> Network Orchestration " + color.END)
    print(color.PURPLE + "\t\t\t 4 -> Onboarding Service " + color.END)
    print(color.BLUE + "\t\t\t 5 -> Previous Menu" + color.END)
    print(color.BLUE + "\t\t\t 6 -> Exit" + color.END)

    print("*" * 75)
    option2=int(input(color.GREEN + "\n\t Enter the Option : " + color.END))
    print(option2)
    print("option",option)
    print('python DNA_Analyzer.py '+str(option)+" "+str(option2))
    if option2 >= 7:
        print(color.BOLD + color.RED + "\t\t\t Invalid Option" + color.END)
    elif option2 == 5:
        main_menu()
    elif option2 == 6:
        #print(color.BOLD + color.GREEN + "\t\t\t Thanks for using the Script !" + color.END)
        cmd=ses.exec('python DNA_Analyzer.py '+str(option)+" "+str(option2))
        
        print(cmd)
    else:
        print(color.BOLD + color.BLUE + "\t\t\t\t " + "Options" + color.END)
        print(color.PURPLE + "\t\t\t\t\t 1 -> Analysis of Existing Log File " + color.END)
        print(color.PURPLE + "\t\t\t\t\t 2 -> Analyze Live Log " + color.END)
        print(color.BLUE + "\t\t\t\t\t 3 -> Exit " + color.END)

        log_option=int(input(color.GREEN + "\n\t Enter the Log Option : " + color.END))
        if log_option==1:
            try:
                filepath = raw_input(color.PURPLE + "\n\t Enter RCA or Log Location : " + color.END)
            except:
                filepath = input(color.PURPLE + "\n\t Enter RCA or Log Location : " + color.END)
        
            cmd=ses.exec('python DNA_Analyzer.py '+str(option)+" "+str(option2)+" "+str(log_option)+" "+filepath) #4argumets
            print("error")
        cmd=ses.exec('python DNA_Analyzer.py '+str(option)+" "+str(option2)+" "+str(log_option)) # 3arguments
        print(cmd)

def end():
    print(color.BOLD+color.DARKCYAN )
    print("*" * 102)
    print("*****"+" "* 92+"*****");
    print("*****"+" " * 30+"Thanks for using DNA Analyzer !! "+" "* 29+"*****")
    print("*****"+" " * 2+"Logs and Reports are available at dna_analyzer_logs and dna_analyzer_reports directory.".format(version)+" "* 3+"*****")
    print("*****"+" "* 92+"*****");
    print("*" * 102+color.END)


client=certificate_login("rithkris@cisco.com",private_key_password="Sprk1824!")

service=client.service('xf0v-wkrx-lho7').wait()

dnac=service.inventory['dnac']


print("Generating challenge..")


ses=dnac.terminal().wait()
cmd=ses.exec("_shell")

print("Here's the challenge data to sign the challenge:\n",cmd.split('\n')[3])
print("\nUse the below link to sign the challenge and paste back the token:\n https://swims.cisco.com/aberto/web/sign")
token=input("Enter the token:")

cmd=ses.exec("_shell -v "+token)
print("Successful!\n",cmd.split('\n')[2])

cmd=ses.exec('cd /home/maglev/.magshell/DNA_Analyzer_Code-main2/dna_analyzer')

introduction()
end()